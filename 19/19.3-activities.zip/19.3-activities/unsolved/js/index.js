// Activity 1 - add a click event listener that targets the toggle class



// Activity 2 - create a click function that targets the class of searchButton



 // Activity 3
